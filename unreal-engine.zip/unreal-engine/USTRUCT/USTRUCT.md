```cpp
USTRUCT(BlueprintType)  
struct FMyStruct  
{  
    GENERATED_BODY()  
      
};
```