```cpp
//.h
virtual void NativeInitializeAnimation() override

//.cpp
void USlashAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();
}
```