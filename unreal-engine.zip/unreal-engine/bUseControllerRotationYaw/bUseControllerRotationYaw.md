```cpp
uint32 bUseControllerRotationYaw
```