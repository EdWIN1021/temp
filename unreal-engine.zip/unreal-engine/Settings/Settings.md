Dynamic Global Illumination Method -> None
Reflection Method -> None
Shadow Map Method -> Shadow Maps
Motion Blur->false