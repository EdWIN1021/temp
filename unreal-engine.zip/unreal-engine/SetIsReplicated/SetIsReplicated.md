
#UAbilitySystemComponent


```cpp
void SetIsReplicated(bool ShouldReplicate)
```

^ecf7c2

```cpp title:constructor
AbilitySystemComponent->SetIsReplicated(true);
```

^a14d08
