#CharacterMovement 
```cpp
GetCharacterMovement()->RotationRate = FRotator(0.f, 400.f, 0.f);
```

==how quickly the character can turn to face a new direction.==