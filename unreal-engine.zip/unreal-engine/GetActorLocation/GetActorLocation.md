```cpp
GetActorLocation();
```