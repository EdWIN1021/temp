```ad-info
A level blueprint is used to manage and control events and behaviors within a specific level or map in a game.
```
![[bp_open_level_blueprint.png]]