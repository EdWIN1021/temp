## Instance

- if a variable is marked as ==Instance Editable==, the variable's value can be changed in the Level for each of the instances without affecting the values held by the other instances.

## Inheritance
- A Blueprint Class can only have one parent class but can have several child classes.
-  Creating a function in the parent class and override it in the child classes with different implementations.