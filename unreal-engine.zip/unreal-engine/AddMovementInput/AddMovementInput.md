```cpp
virtual void AddMovementInput(
    FVector WorldDirection, 
    float ScaleValue = 1, 
    bool bForce = false)
```