```cpp
FInputAxisBinding& BindAxis<UserClass>(const FName AxisName, UserClass* Object, FInputAxisHandlerSignature::TMethodPtr<UserClass> Func)
```

