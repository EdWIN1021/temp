- & restricts a character's movement to a specific plane.
```cpp
GetCharacterMovement()->bConstrainToPlane = true;
```
