```cpp
uint32 bUseControllerRotationPitch
```