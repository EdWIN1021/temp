```cpp
FString Name = GetName();
```