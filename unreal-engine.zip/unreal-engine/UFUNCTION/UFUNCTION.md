```cpp
UFUNCTION(BlueprintCallable)
UFUNCTION(BlueprintPure)
UFUNCTION(BlueprintImplementableEvent)
```