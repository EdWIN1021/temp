- & It determines how quickly the character decelerates when it stops walking.
```cpp
GetCharacterMovement()->BrakingDecelerationWalking = 2000.f;
```
#CharacterMovement 