
```cpp
inline void Init<Attribute>(float NewVal)
```

```cpp
U<Project>AttributeSet::U<Project>AttributeSet()  
{  
    Init<Attribute>(50.f);   
}
```