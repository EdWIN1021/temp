```cpp
inline USceneComponent* GetRootComponent() const
```