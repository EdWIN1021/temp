```cpp
virtual void SetCollisionResponseToChannel(
    ECollisionChannel Channel, 
    ECollisionResponse NewResponse)
```