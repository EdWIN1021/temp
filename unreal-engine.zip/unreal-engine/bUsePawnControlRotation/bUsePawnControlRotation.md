#USpringArmComponent #UCameraComponent
- It determines whether the camera or the spring arm should use the pawn's control rotation.