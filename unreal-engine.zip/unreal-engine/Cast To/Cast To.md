#blueprint
- The node is used to convert an object reference from one type to another in Blueprint, specifically from a base class type to a derived class type or between other compatible types.