Gameplay Effects (GEs) represent a variety of game mechanics that can modify character attributes, apply buffs or debuffs, trigger events, or manage the state of a character.

- Data Only
- Don't subclass UGameplayEffect
- Change Attributes through
	- Modifiers
	- Executions
   