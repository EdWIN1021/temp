```cpp
GetActorForwardVector();
```