```cpp
SetActorRotation(FRotator(0.f, 45.f, 0.f));
```