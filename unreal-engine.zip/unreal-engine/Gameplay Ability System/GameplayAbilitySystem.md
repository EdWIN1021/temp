Edit -> Plugins -> Gameplay Abilities

```cpp
PublicDependencyModuleNames.AddRange(new string[] { "GameplayAbilities", "GameplayTags", "GameplayTasks" });
```