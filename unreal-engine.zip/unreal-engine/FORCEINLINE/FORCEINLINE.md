```cpp
// Making its code directly inserted at each point the function is called  
FORCEINLINE void SetOverlapingItem(AItem* Item) { OverlappingItem = Item; }
```