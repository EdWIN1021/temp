```cpp
inline static TSubsystemClass* GetSubsystem<TSubsystemClass>(const ULocalPlayer* LocalPlayer)
```