```cpp
virtual void AddMappingContext(
    const UInputMappingContext* MappingContext, 
    int32 Priority, 
    const FModifyContextOptions& Options = FModifyContextOptions())
```
