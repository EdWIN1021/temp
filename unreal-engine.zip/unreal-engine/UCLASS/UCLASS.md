- & It is a macro used to define an abstract class.

```cpp
UCLASS(Abstract)
```