```cpp
UWorld* World = GetWorld();
```
