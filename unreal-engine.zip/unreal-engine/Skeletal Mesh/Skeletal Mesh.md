- This Component is a Skeletal Mesh that visually represents the character. 
- The animation of the Mesh Component is controlled by an animation Blueprint.

