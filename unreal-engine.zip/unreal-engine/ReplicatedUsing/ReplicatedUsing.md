[[UPROPERTY]]
```cpp
UPROPERTY(ReplicatedUsing = OnRep_<Attribute>)
```