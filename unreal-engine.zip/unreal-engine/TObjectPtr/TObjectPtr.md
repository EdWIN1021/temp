- & reducing the risk of dangling pointers and ensuring better memory management.

