```cpp
virtual void SetCollisionEnabled(ECollisionEnabled::Type NewType)
```