## bCanEverTick

- & It indicates that the actor should not receive tick updates.

```cpp
PrimaryActorTick.bCanEverTick = false
```