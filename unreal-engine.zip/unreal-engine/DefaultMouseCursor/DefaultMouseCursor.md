```cpp
DefaultMouseCursor = EMouseCursor::Default;
```