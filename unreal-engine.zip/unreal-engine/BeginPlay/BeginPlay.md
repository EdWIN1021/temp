```cpp
protected:  
  virtual void BeginPlay() override;
```