```cpp
SetActorLocation(FVector(0.f, 0.f, 50.f));
```