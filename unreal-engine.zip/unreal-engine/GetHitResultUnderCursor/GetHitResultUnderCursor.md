```cpp
bool GetHitResultUnderCursor(
    ECollisionChannel TraceChannel, 
    bool bTraceComplex, 
    FHitResult& HitResult) const
```