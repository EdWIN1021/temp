```cpp
void SetupAttachment(USceneComponent* InParent, FName InSocketName = NAME_None)
```