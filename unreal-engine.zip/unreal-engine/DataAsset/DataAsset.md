Miscellaneous -> Data Asset
![[Screenshot 2024-09-26 at 10.18.18 PM.png]]