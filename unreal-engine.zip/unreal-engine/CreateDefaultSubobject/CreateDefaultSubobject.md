```cpp
TReturnType* CreateDefaultSubobject<TReturnType>(FName SubobjectName, bool bTransient = false)
```
