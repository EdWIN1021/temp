-  & When bOrientRotationToMovement is set to true, the character will automatically rotate to face the direction it is moving.
```cpp
GetCharacterMovement()->bOrientRotationToMovement = true;
```

#CharacterMovement