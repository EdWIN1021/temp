- This applies the effect specification to the target actor
- TargetASC: [[UAbilitySystemComponent]]

```cpp
TargetASC->ApplyGameplayEffectSpecToSelf(*EffectSpecHandle.Data.Get());
```