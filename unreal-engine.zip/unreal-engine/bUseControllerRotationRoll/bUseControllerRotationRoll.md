```cpp
uint32 bUseControllerRotationRoll
```