```cpp
virtual void PossessedBy(AController* NewController) override
```
#ACharacter