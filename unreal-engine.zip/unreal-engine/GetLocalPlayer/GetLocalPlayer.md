```cpp
ULocalPlayer* GetLocalPlayer() const
```