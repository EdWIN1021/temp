```cpp
AddControllerPitchInput(Value);
```