```cpp
UE_LOG(LogTemp, Warning, TEXT("Begin Play Called!"));
UE_LOG(LogTemp, Warning, TEXT("DeltaTime: %f"), DeltaTime);
```