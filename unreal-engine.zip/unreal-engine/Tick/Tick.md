- & Called each frame by the engine
```cpp
Tick()
```