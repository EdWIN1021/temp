```cpp
float TargetArmLength
```