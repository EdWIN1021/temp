- This can help track who applied the effect for potential gameplay purposes

```cpp
EffectContextHandle.AddSourceObject(this);
```