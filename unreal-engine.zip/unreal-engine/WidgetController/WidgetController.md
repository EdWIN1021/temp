- Simple Object
![[Screenshot 2024-09-25 at 2.39.13 PM.png]]