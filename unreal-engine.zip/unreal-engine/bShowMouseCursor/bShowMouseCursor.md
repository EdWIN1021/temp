```cpp
uint32 bShowMouseCursor
```