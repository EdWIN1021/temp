```cpp
inline USkeletalMeshComponent* GetMesh() const 
```